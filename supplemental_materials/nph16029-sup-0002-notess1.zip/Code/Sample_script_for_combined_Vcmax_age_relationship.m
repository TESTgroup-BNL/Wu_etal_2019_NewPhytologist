clc
clear

%**************************************************************************
% The purpose of this code is to show how a combination of spectra-age
% and spectra-Vcmax25 models can help infer the Vcmax25-age relationship
% using leaf reflectance spectra as the only input.
% 
% Jin Wu, June 2019, University of Hong Kong
%**************************************************************************

%% Load the PLSR regression coefficients
[num1 txt1 raw1]=xlsread('./Data/PLSR Regression Coefficients.xlsx','spectra-Age PLSR coefficients');
[num2 txt2 raw2]=xlsread('./Data/PLSR Regression Coefficients.xlsx','spectra-Vcmax25 PLSR coefficien');

PLSR_coefficients_Age=num1(2:end,:); %% PLSR regression coefficients for leaf age
PLSR_coefficients_V25=num2(2:end,:); %% PLSR regression coefficients for leaf Vcmax25

clear num1 txt1 raw1 num2 txt2 raw2;

%% Load the sample leaf reflectance data
[num3 txt3 raw3]=xlsread('./Data/Sample leaf reflectance data.xlsx','Sample leaf reflectance data');
X=num3(2:end,:); %% sample leaf reflectance

clear num3 txt3 raw3;

%% Infer Vcmax25 and leaf age from leaf reflectance
X1=[X(1,:)*0+1
    X]; 
V25_sq_pr=X1'*PLSR_coefficients_V25; %% PLSR model to infer the square root of Vcmax25
V25_pr=V25_sq_pr.^2; %% PLSR model to infer Vcmax25

Age_sq_pr=X1'*PLSR_coefficients_Age; %% PLSR model to infer the square root of leaf age
Age_pr=Age_sq_pr.^2; %% PLSR model to infer leaf age


%% Calculate mean, standard deviation, 2.5 percentile and 97.5 percentile of Vcmax25 and leaf age based on 100-times ensemble PLSR simulations
for i=1:length(V25_pr(:,1))  
    V25_pr_mean(i,1)=mean(V25_pr(i,:)); 
    V25_pr_std(i,1)=std(V25_pr(i,:));
    V25_pr_025(i,1)=prctile(V25_pr(i,:), 2.5);
    V25_pr_975(i,1)=prctile(V25_pr(i,:), 97.5);
end

for i=1:length(Age_pr(:,1))  
    Age_pr_mean(i,1)=mean(Age_pr(i,:)); 
    Age_pr_std(i,1)=std(Age_pr(i,:));
    Age_pr_025(i,1)=prctile(Age_pr(i,:), 2.5);
    Age_pr_975(i,1)=prctile(Age_pr(i,:), 97.5);
end

%% Plot spectra-based Vcmax25-age relationship
figure('color','white');
hold on;
for i=1:length(Age_pr_mean)
    plot([Age_pr_025(i,1) Age_pr_975(i,1)],[V25_pr_mean(i,1) V25_pr_mean(i,1)],'-','color',[0.5 0.5 0.5],'LineWidth',1);
    plot([Age_pr_mean(i,1) Age_pr_mean(i,1)],[V25_pr_025(i,1) V25_pr_975(i,1)],'-','color',[0.5 0.5 0.5],'LineWidth',1);
    plot(Age_pr_mean(i,1), V25_pr_mean(i,1),'o','MarkerSize',5, 'MarkerFaceColor',[0.5 0.5 0.5],'MarkerEdgeColor',[0.5 0.5 0.5]);
end
box on;
set(gca,'fontsize',12);
xlabel('Spectra predicted leaf age (days)','fontsize',14);
ylabel('Spectra predicted Vcmax25','fontsize',14);
axis([0 400 0 75]);